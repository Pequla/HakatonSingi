import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl, SafeUrl} from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
  
export class AppComponent {
  
  title: string = "Sharingan";
  project_name: string = "";
  current_language_english: boolean = true;
  choose_camera: string = "";
  choose_camera_text: string = "";
  currently_active_camera_text: string = "";
  saved_cameras_text: string = "";
  vfc_list: Array<String> = ["t"];
  camera_list: Array<String> = ["t"];
  camera_name: string = "camera-name";
  copyright_text: string = "Akatsuki";
  current_year: number = new Date().getFullYear();
  isLandingPage: boolean = false;
  isChooseCamera: boolean = false;
  isSelectedCamera: boolean = false;
  video_source: SafeResourceUrl = "";
  
  constructor(private sanitizer: DomSanitizer, private httpc:HttpClient) {  }

  ngOnInit() {
    this.changeLanguage(this.current_language_english);
    this.backToLandingPage();
  }

  backToLandingPage(): void {
    this.isLandingPage = true;
    this.isChooseCamera = false;
    this.isSelectedCamera = false;
  }

  chooseCamera(): void {
    this.isLandingPage = false;
    this.isChooseCamera = true;
    this.isSelectedCamera = false;
    /* this.httpc.get("http://127.0.0.1:8080/cameraList").subscribe(data => {
      this.camera_list = data;
      console.log(data);
    }); */
  }

  selectCamera(camera_id: number): void {
    this.isLandingPage = false;
    this.isChooseCamera = false;
    this.isSelectedCamera = true;
    this.camera_name = this.currently_active_camera_text + camera_id;
    /* this.video_source = this.httpc.post("http://127.0.0.1:8080/getOpenCVVideo",this.camera_list[camera_id]).subscribe(video_data => {
      this.video_source = video_data;
      console.log(video_data);
    }); */
    /* this.video_source = this.sanitizer.bypassSecurityTrustResourceUrl("../assets/test.mp4"); */
  }

  switchToFeed(feed_id: number): void {
    console.log("Switched to feed #" + feed_id);
  }

  changeLanguage(language: boolean): void {
    this.current_language_english = language;
    if (language) {
      this.project_name = "Sharingan";
      this.choose_camera = "Choose camera";
      this.choose_camera_text = "Please select a video source";
      this.currently_active_camera_text = "Active camera: ";
    }
    else {
      this.project_name = "Шаринган";
      this.choose_camera = "Одаберите камеру";
      this.choose_camera_text = "Одаберите видео улаз";
      this.currently_active_camera_text = "Активна камера: ";
    }
  }
}